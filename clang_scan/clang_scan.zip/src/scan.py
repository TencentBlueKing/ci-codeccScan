import json
import sys
import getopt
sys.path.append('./third/')
import io
import os
import shutil
from biplist import *

ENABLE_CHECKER = ""
ENABLE_CHECKER_LIST = []
CHECKER_OPTIONS = []
SCAN_PATH = ""
SCAN_TYPE = "full"
BIN_PATH = ""
SUB_PATH = ""
BUILD_SCRIPT = ""
OUTPUT_JSON = {
    "code": 0,
    "message": "Scan begin",
    "defects": []
}


#load input.json file
def load_input_json(input_file):
    f = io.open(input_file, encoding='utf-8')
    setting = json.load(f)
    #print(setting['openCheckers'])

    global ENABLE_CHECKER
    global CHECKER_OPTIONS
    for checker in setting['openCheckers']:
        checker_name = checker['checkerName'].replace("-", ".").replace("..", "-")
        ENABLE_CHECKER_LIST.append(checker_name)
        ENABLE_CHECKER += " -enable-checker " + checker_name

        ##checkerOption begin
        if 'checkerOptions' in checker:
            for option in checker['checkerOptions']:
                if option['checkerOptionValue'] == "":
                    continue
                config = checker_name + ":" + option['checkerOptionName'] + "=" + option['checkerOptionValue']
                CHECKER_OPTIONS.append(config)
        ##checkerOption end

    if 'scanPath' in setting:
        global SCAN_PATH
        SCAN_PATH = setting['scanPath']
        print("scan_path:" + SCAN_PATH)

    if 'scanType' in setting:
        global SCAN_TYPE
        SCAN_TYPE = setting['scanType']
    
    if 'toolOptions' in setting and len(setting['toolOptions']) > 0:
        global BIN_PATH
        global BUILD_SCRIPT
        for option in setting['toolOptions']:
            if 'optionName' in option and option['optionName'] == 'subPath':
                BIN_PATH = option['optionValue']
                break
        
        for option in setting['toolOptions']:
            if 'optionName' in option and option['optionName'] == 'SHELL':
                shell_option = option['optionValue'].split('\n')
                for s in range(0, len(shell_option)):
                    if shell_option[s].strip() != "":
                        if not shell_option[s].strip().startswith('#'):
                            BUILD_SCRIPT = shell_option[s]
                            break
        print("bin_path: " + BIN_PATH)
     
    print("enableCheckers:" + ENABLE_CHECKER)


#analyze tmp plist files
def analyze_plist(tmp_log_loc, outputfile):
    global OUTPUT_JSON
    global SCAN_PATH
    for parent, _, filenames in os.walk(tmp_log_loc):
        for filename in filenames:
            if filename.endswith('.plist'):
                plist = readPlist(parent + '/' + filename)
                if(plist['files'] != []):
                    for diagnostic in plist['diagnostics']:
                        if diagnostic['check_name'] != "" and diagnostic['check_name'] in ENABLE_CHECKER_LIST:
                            filePathTemp = find_file(SCAN_PATH, plist['files'][0])
                            if filePathTemp == None:
                                print("find file null")
                                filePathTemp = ""
                            json_temp = {
                                "filePath": filePathTemp,
                                "line": diagnostic['location']['line'],
                                "checkerName": diagnostic['check_name'].replace("-", "--").replace(".", "-"),
                                "description": diagnostic['description']
                            }
                            if json_temp['checkerName'] != "" and json_temp['filePath'] != "" and json_temp['line'] != "":
                                OUTPUT_JSON['defects'].append(json_temp)
                            else:
                                print("result has null part")
                                print("null result is: " + json_temp)
    OUTPUT_JSON['message'] = "scan complete"
    json_data = json.dumps(OUTPUT_JSON)
    print(json_data)
    file_path = os.path.dirname(outputfile)
    if not os.path.exists(file_path):
        os.makedirs(file_path)
    f = open(outputfile, 'w')
    f.write(json_data)
    f.close()
    print('generate output file: ' + outputfile)

def find_file(start, name):
    if os.path.exists(name):
        return name
    elif os.path.exists(start + '/' + name):
        return start + '/' + name
    else:
        for relpath, dirs, files in os.walk(start):
            if name in files:
                full_path = os.path.join(start, relpath, name)
                return os.path.normpath(os.path.abspath(full_path))

#remove plistTemp logs
def remove_plist(tmp_log_loc):
    del_list = os.listdir(tmp_log_loc)
    for f in del_list:
        file_path = os.path.join(tmp_log_loc, f)
        if os.path.isfile(file_path):
            os.remove(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)


#main function
def main(argv):
    input_file = ''
    output_file = ''
    try:
        opts, _ = getopt.getopt(argv, "hi:o:", ["input=", "output="])
    except getopt.GetoptError:
        print('clang.py --input <inputfile> --output <outputfile>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('clang.py --input <inputfile> --output <outputfile>')
        elif opt in ("-i", "--input"):
            input_file = arg
        elif opt in ("-o", "--output"):
            output_file = arg
    load_input_json(input_file)

    global SCAN_PATH
    global SUB_PATH
    global BIN_PATH
    global BUILD_SCRIPT
    #scanLoc = "/Users/codecc/Desktop/clang8.0-static-analyzer/bin/"
    tmp_log_loc = SCAN_PATH + "/clang-tmp/"
    #tmpPath = scanLoc + tmp_log_loc
    if not os.path.exists(tmp_log_loc):
        os.makedirs(tmp_log_loc)
    else:
        remove_plist(tmp_log_loc)

    scan_cmd = BIN_PATH + "/bin/scan-build -plist --keep-going "
    log_out_cmd = " -o " + tmp_log_loc
    
    global ENABLE_CHECKER
    enable_checker_cmd = ENABLE_CHECKER

    analyze_config_cmd = " "
    if len(CHECKER_OPTIONS) > 0:
        analyze_config_cmd += " -analyzer-config "
        for i in range(0, len(CHECKER_OPTIONS)):
            analyze_config_cmd += CHECKER_OPTIONS[i]
            if i != len(CHECKER_OPTIONS)-1 :
                analyze_config_cmd += ","
    
    print('command: ' + scan_cmd + log_out_cmd + enable_checker_cmd + analyze_config_cmd + ' ' + BUILD_SCRIPT)
    os.system(scan_cmd + log_out_cmd + enable_checker_cmd + analyze_config_cmd + ' ' + BUILD_SCRIPT)

    analyze_plist(tmp_log_loc, output_file)


if __name__ == "__main__":
    main(sys.argv[1:])
