## CLANG工具

基于开源工具 [Clang Static Analyzer](https://clang-analyzer.llvm.org/)，可对C/C++、Objective-C项目检查潜在的代码bug

版本：clang+llvm-11.0

checkers.json--规则集，包含85条工具版本所支持的检查规则，详细请查看 [Clang Available Checkers](https://releases.llvm.org/11.0.0/tools/clang/docs/analyzer/checkers.html) 。
