# coding=utf-8
import sys
import getopt
import os
import json
import io

ENABLE_CHECKER = []
SCAN_PATH = ""
BUILD_SCRIPT = ""
outputJson = {
    "code": 0,
    "message": "scan begin",
    "defects": []
}


def load_input_json(input_file):
    f = io.open(input_file, encoding='utf-8')
    setting = json.load(f)
    checker_count = len(setting['openCheckers'])

    global ENABLE_CHECKER
    for i in range(0, checker_count):
        checker_name = setting['openCheckers'][i]['checkerName']
        ENABLE_CHECKER.append(checker_name)
    print(ENABLE_CHECKER)

    if 'scanPath' in setting:
        global SCAN_PATH
        SCAN_PATH = setting['scanPath']

    if 'buildScript' in setting:
        global BUILD_SCRIPT
        BUILD_SCRIPT = setting['buildScript']


def analyze_warning(warning_log, outputfile):
    global ENABLE_CHECKER
    with open(warning_log) as f:
        for lines in f:
            if '[-W' in lines:
                json_temp = {
                    "filePath": "",
                    "line": "",
                    "checkerName": "",
                    "description": ""
                }
                if 'warning:' in lines:
                    line_temps = lines.split('warning:')
                elif '警告：' in lines:
                    line_temps = lines.split('警告：')
                else:
                    print('there is no warning: in this line')
                    continue
                if len(line_temps) > 1:
                    info_list = line_temps[0].split(':')
                    filePathTemp = find_file(SCAN_PATH, info_list[0].strip())
                    if filePathTemp != None:
                        json_temp['filePath'] = filePathTemp
                    json_temp['line'] = info_list[1].strip()
                    warn_list = line_temps[1].split('[-W')
                    if len(warn_list) > 2:
                        print("file info contains '[-W' .")
                    else:
                        checker = warn_list[1].strip()[:-1]
                        if checker in ENABLE_CHECKER:
                            json_temp['checkerName'] = checker
                            json_temp['description'] = warn_list[0].strip()
                if json_temp['checkerName'] != "" and json_temp['filePath'] != "" and json_temp['line'] != "" \
                and json_temp['description'] != "":
                    outputJson['defects'].append(json_temp)
    outputJson['defects'] = [dict(t) for t in set([tuple(d.items()) for d in outputJson['defects']])]
    outputJson['message'] = "scan complete"
    json_data = json.dumps(outputJson)
    print(json_data)
    filepath = os.path.dirname(outputfile)
    if not os.path.exists(filepath):
        os.makedirs(filepath)
    f = open(outputfile, 'w')
    f.write(json_data)
    f.close()
    print('generate output file: ' + outputfile)

def find_file(start, name):
    if os.path.exists(name):
        return name
    elif os.path.exists(start + '/' + name):
        return start + '/' + name
    else:
        for relpath, dirs, files in os.walk(start):
            if name in files:
                full_path = os.path.join(start, relpath, name)
                return os.path.normpath(os.path.abspath(full_path))

def delete_log(warn_log_loc):
    if os.path.exists(warn_log_loc):
        os.remove(warn_log_loc)
        print("delete codecc-clangwarning.log success.")
    else:
        print("codecc-clangwarning.log not exists can't be deleted.")


def main(argv):
    inputfile = ''
    outputfile = ''
    try:
        opts, _ = getopt.getopt(argv, "hi:o:", ["input=", "output="])
    except getopt.GetoptError:
        print('clangwarning.py --input <inputfile> --output <outputfile>')
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print('clangwarning.py --input <inputfile> --output <outputfile>')
        elif opt in ("-i", "--input"):
            inputfile = arg
        elif opt in ("-o", "--output"):
            outputfile = arg
    load_input_json(inputfile)

    global SCAN_PATH
    global BUILD_SCRIPT
    warn_log_loc = SCAN_PATH + "/codecc-clangwarning.log"
    print("command: " + "sh " + BUILD_SCRIPT + " 2> " + warn_log_loc)
    os.system("sh " + BUILD_SCRIPT + " 2> " + warn_log_loc)
    if not os.path.exists(warn_log_loc):
        print("--'codecc-clangwarning.log' file not exists, please compile and generate again--")
    else:
        analyze_warning(warn_log_loc, outputfile)
        delete_log(warn_log_loc)

if __name__ == "__main__":
    main(sys.argv[1:])
