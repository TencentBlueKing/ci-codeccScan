// build

package main

import (
	x "./burnin"
)

func main() {
	x.NewSomething()
}
