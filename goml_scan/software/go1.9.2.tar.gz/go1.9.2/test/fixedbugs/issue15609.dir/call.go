// +build !amd64,!386

package main

func jump() {
	target()
}
