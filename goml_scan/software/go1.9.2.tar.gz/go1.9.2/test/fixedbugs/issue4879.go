// compiledir

// Copyright 2013 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Issue 4879: export data misses the '&' for some
// composite literals in inlined bodies.

package ignored
