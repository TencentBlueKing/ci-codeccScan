// FileNameCaseMismatch.Swift
// Copyright © 2016
struct A {}
