// 
// Copyright © 2016
struct A {}
