// FileNameMatchingSimple.swift
// Copyright © 2016
struct A {}
