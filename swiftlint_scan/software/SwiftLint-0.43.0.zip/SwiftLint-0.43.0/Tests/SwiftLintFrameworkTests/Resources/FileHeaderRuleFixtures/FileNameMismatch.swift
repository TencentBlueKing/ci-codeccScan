// AFileNameMismatch.swift
// Copyright © 2016
struct A {}
