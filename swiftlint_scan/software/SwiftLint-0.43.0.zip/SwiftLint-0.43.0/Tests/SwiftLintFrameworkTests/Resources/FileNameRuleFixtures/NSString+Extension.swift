struct MyStruct {}
class MyClass {}

extension NSString {
  func asdf() {}
}
