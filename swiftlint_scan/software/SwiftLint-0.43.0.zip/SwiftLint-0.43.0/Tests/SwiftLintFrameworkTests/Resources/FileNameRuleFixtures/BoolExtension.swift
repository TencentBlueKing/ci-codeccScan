struct MyStruct {}
class MyClass {}

extension Bool {
  func toggle() {}
}
