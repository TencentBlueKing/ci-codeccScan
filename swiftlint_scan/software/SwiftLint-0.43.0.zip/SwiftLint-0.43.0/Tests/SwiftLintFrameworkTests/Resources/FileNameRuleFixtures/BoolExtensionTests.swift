@testable import SomeModule
import XCTest

class BoolExtensionTests: XCTestCase {
    func testExample() {
        // some code
    }
}
