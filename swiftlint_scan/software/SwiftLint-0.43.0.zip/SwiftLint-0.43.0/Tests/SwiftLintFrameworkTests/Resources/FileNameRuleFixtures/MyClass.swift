struct MyStruct {}
class MyClass {}
