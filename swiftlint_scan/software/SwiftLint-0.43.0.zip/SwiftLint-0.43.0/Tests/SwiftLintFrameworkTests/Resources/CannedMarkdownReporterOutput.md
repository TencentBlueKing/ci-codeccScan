file | line | severity | reason | rule_id
--- | --- | --- | --- | ---
filename | 1 | :warning: | Line Length: Violation Reason. | line_length
filename | 1 | :stop\_sign: | Line Length: Violation Reason. | line_length
filename | 1 | :stop\_sign: | Syntactic Sugar: Shorthand syntactic sugar should be used, i.e. [Int] instead of Array<Int>. | syntactic_sugar
 |  | :stop\_sign: | Colon: Colons should be next to the identifier when specifying a type and next to the key in dictionary literals. | colon