internal protocol CacheDescriptionProvider {
    var cacheDescription: String { get }
}
